import { useState } from "react";
import { Sparkles, TrendingUp } from "lucide-react";

export function MakePrediction() {
  const [formData, setFormData] = useState({
    feature1: "",
    feature2: "",
    feature3: "",
    feature4: "",
    feature5: "",
    feature6: "",
    feature7: "",
    feature8: "",
  });
  const [prediction, setPrediction] = useState<{
    class: string;
    probability: number;
  } | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePredict = () => {
    // Mock prediction
    const classes = ["Class A", "Class B", "Class C"];
    const randomClass = classes[Math.floor(Math.random() * classes.length)];
    const randomProb = 75 + Math.random() * 20;
    setPrediction({ class: randomClass, probability: randomProb });
  };

  const isFormValid = Object.values(formData).every((val) => val !== "");

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">Make Prediction</h1>
        <p className="mt-2 text-slate-400">
          Input feature values to predict the classification result
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Input Form */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/50 p-8 shadow-2xl backdrop-blur-xl">
          <h2 className="mb-6 text-xl font-semibold text-white">Input Features</h2>

          <div className="space-y-4">
            {Object.keys(formData).map((key, index) => (
              <div key={key}>
                <label className="mb-2 block text-sm font-medium text-slate-300">
                  Feature {index + 1}
                </label>
                <input
                  type="number"
                  name={key}
                  value={formData[key as keyof typeof formData]}
                  onChange={handleInputChange}
                  placeholder={`Enter value for feature ${index + 1}`}
                  className="w-full rounded-lg border border-white/10 bg-slate-800/50 px-4 py-3 text-white placeholder-slate-500 transition-all focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>
            ))}

            <button
              onClick={handlePredict}
              disabled={!isFormValid}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 px-6 py-4 font-semibold text-white shadow-lg shadow-blue-500/50 transition-all hover:shadow-xl hover:shadow-blue-500/60 disabled:cursor-not-allowed disabled:opacity-50 disabled:shadow-none"
            >
              <Sparkles className="size-5" />
              Predict Classification
            </button>
          </div>
        </div>

        {/* Result Card */}
        <div className="rounded-2xl border border-white/10 bg-slate-900/50 p-8 shadow-2xl backdrop-blur-xl">
          <h2 className="mb-6 text-xl font-semibold text-white">Prediction Result</h2>

          {prediction ? (
            <div className="space-y-6">
              {/* Predicted Class */}
              <div>
                <p className="mb-2 text-sm text-slate-400">Predicted Class</p>
                <div className="flex items-center gap-3 rounded-lg bg-gradient-to-r from-blue-500/20 to-purple-600/20 p-4 shadow-lg shadow-blue-500/20">
                  <TrendingUp className="size-6 text-blue-400" />
                  <span className="text-2xl font-bold text-white">
                    {prediction.class}
                  </span>
                </div>
              </div>

              {/* Probability */}
              <div>
                <p className="mb-2 text-sm text-slate-400">Probability</p>
                <div className="rounded-lg bg-slate-800/50 p-4">
                  <div className="mb-2 flex items-end justify-between">
                    <span className="text-sm text-slate-400">Confidence</span>
                    <span className="text-2xl font-bold text-blue-400">
                      {prediction.probability.toFixed(1)}%
                    </span>
                  </div>
                  <div className="relative h-3 w-full overflow-hidden rounded-full bg-slate-700/50">
                    <div
                      className="h-full bg-gradient-to-r from-blue-500 to-purple-600 transition-all duration-500"
                      style={{ width: `${prediction.probability}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Confidence Level */}
              <div className="rounded-lg border border-white/10 bg-slate-800/30 p-4">
                <div className="flex items-start gap-3">
                  <div className="rounded-full bg-green-500/20 p-2">
                    <Sparkles className="size-5 text-green-400" />
                  </div>
                  <div>
                    <p className="font-medium text-white">
                      {prediction.probability >= 90
                        ? "Very High Confidence"
                        : prediction.probability >= 80
                        ? "High Confidence"
                        : "Moderate Confidence"}
                    </p>
                    <p className="mt-1 text-sm text-slate-400">
                      The model is{" "}
                      {prediction.probability >= 90
                        ? "very confident"
                        : prediction.probability >= 80
                        ? "confident"
                        : "moderately confident"}{" "}
                      about this prediction.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex h-64 items-center justify-center">
              <div className="text-center">
                <div className="mx-auto mb-4 flex size-16 items-center justify-center rounded-full bg-slate-800/50">
                  <Sparkles className="size-8 text-slate-600" />
                </div>
                <p className="text-slate-500">
                  Fill in all features and click Predict to see results
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
